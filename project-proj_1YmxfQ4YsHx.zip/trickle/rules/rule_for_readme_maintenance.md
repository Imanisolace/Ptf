When project is updated
- Check if README.md needs updates to reflect new features, sections, or changes
- Update the Features section if new functionality is added
- Update the Sections list if page structure changes
- Keep the documentation accurate and in sync with the actual project